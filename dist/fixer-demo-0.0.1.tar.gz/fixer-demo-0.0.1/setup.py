from setuptools import setup

setup(
    name='fixer-demo',
    version='0.0.1',
    description='Fixer Demo',
    author='Amir',
    author_email='amirb938@gmail.com',
    license='MIT',
    packages=['fixer'])
