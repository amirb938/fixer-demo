# import requests
# from config import url


def get_currency_rates():
    # response = requests.get(url)
    # data = response.json()
    # return data
    return "test currency"
