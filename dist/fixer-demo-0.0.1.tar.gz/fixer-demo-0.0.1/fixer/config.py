BASE_PATH = "http://data.fixer.io/api/latest?format=1&access_key="
API_KEY = "c900e85aad6d4f2e29d594d8c355814a"

url = BASE_PATH + API_KEY
