from fixer.handler import get_currency_rates

__all__ = ['get_currency_rates']
